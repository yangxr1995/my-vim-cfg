.. _ctags-lang-fortran(7):

==============================================================
ctags-lang-fortran
==============================================================

Random notes about tagging Fortran source code with Universal Ctags

:Version: 6.1.0
:Manual group: Universal Ctags
:Manual section: 7

SYNOPSIS
--------
|	**ctags** ... --languages=+Fortran ...
|	**ctags** ... --language-force=Fortran ...
|	**ctags** ... --map-Fortran=+.f ...

DESCRIPTION
-----------
This man page gathers random notes about tagging FORTRAN source code.

VERSIONS
--------

Change since "0.0"
~~~~~~~~~~~~~~~~~~

* New extra ``linkName``.

SEE ALSO
--------
:ref:`ctags(1) <ctags(1)>`
