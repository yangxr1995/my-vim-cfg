======================================================================
NEWS
======================================================================

:Maintainer: Masatake YAMATO <yamato@redhat.com>

.. contents:: `Table of contents`
	:depth: 3
	:local:

----

.. toctree::
	:maxdepth: 1

	version ?.?.? <news/HEAD.rst>
	version 6.0.0 <news/6-0-0.rst>
